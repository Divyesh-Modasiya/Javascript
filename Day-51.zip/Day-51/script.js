function loading(){
    const data = `<center>
    <nav>
        <a href="">Home</a>
        <a href="">About</a>
        <a href="">Contact</a>
        <a href="">Blog</a>

    </nav>
</center>`
document.getElementById("main").innerHTML = data
}
export{loading}